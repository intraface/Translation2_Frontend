<?php

define('DB_NAME', 'pear');
define('DB_HOST', 'localhost');
define('DB_PASS', '');
define('DB_USER', 'root');

?>